﻿using System;

namespace _04.FishingBoat
{
    class Program
    {
        static void Main(string[] args)
        {
            const int springPrice = 3000;
            const int summerAndAutumnPrice = 4200;
            const int winterPrice = 2600;

            int budjet = int.Parse(Console.ReadLine());
            string season = Console.ReadLine();
            int numberOfFisherman = int.Parse(Console.ReadLine());
            double totalMoney = 0;

            switch (season)
            {
                case "Spring":
                    totalMoney = springPrice;
                    break;
                case "Summer":
                    totalMoney = summerAndAutumnPrice;
                    break;
                case "Autumn":
                    totalMoney = summerAndAutumnPrice;
                    break;
                case "Winter":
                    totalMoney = winterPrice;
                    break;
            }

            if (numberOfFisherman <= 6)
            {
                totalMoney -= totalMoney * 0.10;
            }
            else if (numberOfFisherman <= 11)
            {
                totalMoney -= totalMoney * 0.15;
            }
            else 
            {
                totalMoney -= totalMoney * 0.25;
            }
            if (numberOfFisherman % 2 == 0 && season != "Autumn")
            {
                totalMoney -= totalMoney * 0.5;
            }

            if (budjet >= totalMoney)
            {
                double moneyLeft = budjet - totalMoney;
                Console.WriteLine($"Yes! You have {moneyLeft:f2} leva left.");
            }
            else
            {
                double moneyNedeed = totalMoney - budjet;
                Console.WriteLine($"Not enough money! You need {moneyNedeed:f2} leva.");
            }

        }
    }
}
