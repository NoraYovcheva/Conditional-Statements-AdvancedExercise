﻿using System;

namespace Cinema
{
    class Program
    {
        static void Main(string[] args)
        {
            //•	Premiere – премиерна прожекция, на цена 12.00 лева.
            //•	Normal – стандартна прожекция, на цена 7.50 лева.
            //•	Discount – прожекция за деца, ученици и студенти на намалена цена от 5.00 лева.
            string type = Console.ReadLine();
            int numberOfRows = int.Parse(Console.ReadLine());
            int numberOfColumns = int.Parse(Console.ReadLine());

            double income = 0.0;

            if (type == "Premiere")
            {
                income = numberOfRows * numberOfColumns * 12;
            }
            else if (type == "Normal")
            {
                income = numberOfRows * numberOfColumns * 7.50;
            }
            else if (type == "Discount")
            {
                income = numberOfRows * numberOfColumns * 5.00;
            }

            Console.WriteLine($"{income:f2} leva");
        }
    }
}
