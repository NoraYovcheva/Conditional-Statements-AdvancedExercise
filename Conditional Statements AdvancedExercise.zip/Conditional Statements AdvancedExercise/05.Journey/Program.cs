﻿using System; 

namespace _05.Journey
{
    class Program
    {
        static void Main(string[] args)
        {
            double budjet = double.Parse(Console.ReadLine());
            string season = Console.ReadLine();
            double totalMoney = 0;


            if (budjet <= 100)
            {
                if (season == "summer")
                {
                    totalMoney = budjet * 0.30;
                    Console.WriteLine("Somewhere in Bulgaria");
                    Console.WriteLine($"Camp - {totalMoney:f2}");
                }
                else 
                {
                    totalMoney = budjet * 0.70;
                    Console.WriteLine("Somewhere in Bulgaria");
                    Console.WriteLine($"Hotel - {totalMoney:f2}");
                } 
            }
            else if (budjet <= 1000)
            {
                if (season == "summer")
                {
                    totalMoney = budjet * 0.40;
                    Console.WriteLine("Somewhere in Balkans");
                    Console.WriteLine($"Camp - {totalMoney:f2}");
                }
                else 
                {
                    totalMoney = budjet * 0.80;
                    Console.WriteLine("Somewhere in Balkans");
                    Console.WriteLine($"Hotel - {totalMoney:f2}");
                }
            }
            else
            {
                totalMoney = budjet * 0.90;
                Console.WriteLine("Somewhere in Europe");
                Console.WriteLine($"Hotel - {totalMoney:f2}");
            }
        }
    }
}
