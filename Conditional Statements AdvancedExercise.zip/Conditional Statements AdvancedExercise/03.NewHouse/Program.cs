﻿using System;
using System.Buffers;

namespace _03.NewHouse
{
    class Program
    {
        static void Main(string[] args)
        {
            //Роза Далия   Лале Нарцис  Гладиола
            // 5   3.80    2.80    3   2.50
            const double rosesPrice = 5.00;
            const double dahliasPrice = 3.80;
            const double tulipsPrice = 2.80;
            const double narcissusPrise = 3.00;
            const double gladiolusPrise = 2.50;

            string flowers = Console.ReadLine();
            int numbersOfFlowers = int.Parse(Console.ReadLine());
            double budjet = double.Parse(Console.ReadLine());
            double totalMoney = 0;

            if (flowers == "Roses")
            {
                if (numbersOfFlowers > 80)
                {
                    totalMoney -= numbersOfFlowers * rosesPrice * 0.10;
                }

                totalMoney += numbersOfFlowers * rosesPrice;
            }
            else if (flowers == "Dahlias")
            {
                if (numbersOfFlowers > 90)
                {
                    totalMoney -= numbersOfFlowers * dahliasPrice * 0.15;
                }

                totalMoney += numbersOfFlowers * dahliasPrice;
            }
            else if (flowers == "Tulips")
            {
                if (numbersOfFlowers > 80)
                {
                     totalMoney -= numbersOfFlowers * tulipsPrice * 0.15;
                }

                totalMoney += numbersOfFlowers * tulipsPrice;
            }
            else if (flowers == "Narcissus")
            {
                if (numbersOfFlowers < 120)
                {
                    totalMoney += numbersOfFlowers * narcissusPrise * 0.15;
                }
                
                totalMoney += numbersOfFlowers * narcissusPrise;
            }
            else if (flowers == "Gladiolus")
            {
                if (numbersOfFlowers < 80)
                {
                    totalMoney += numbersOfFlowers * gladiolusPrise * 0.20;
                }
                totalMoney += numbersOfFlowers * gladiolusPrise;
            }
            if (budjet >= totalMoney)
            {
                double moneyLeft = budjet - totalMoney;
                Console.WriteLine($"Hey, you have a great garden with {numbersOfFlowers} {flowers} and {moneyLeft:f2} leva left.");
            }
            else
            {
                double moneyNeeded = totalMoney - budjet;
                Console.WriteLine($"Not enough money, you need {moneyNeeded:f2} leva more.");
            }
        }
    }
}
